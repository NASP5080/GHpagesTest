Check the portfolio! 💼 - https://www.milipernia.com/

A responsive portfolio created as a 3rd project for SheCodes 🧠💼
Hosted with Netlify 
